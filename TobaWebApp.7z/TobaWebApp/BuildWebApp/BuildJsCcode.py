
import sys
import base64
import lzstring 

def bin2header(data, var_name='ccode'):
    out = []
    out.append('var {var_name} = {{'.format(var_name=var_name))
    l = [ data[i:i+12] for i in range(0, len(data), 12) ]
    for i, x in enumerate(l):
        #line = ', '.join([ '0x{val:02x}'.format(val=c) for c in x ])
        line = ', '.join([ '{val}'.format(val=c) for c in x ])
        out.append('  {line}{end_comma}'.format(line=line, end_comma=',' if i<len(l)-1 else ''))
    out.append('};')
    return '\n'.join(out)


USE_NORMAL = False
USE_BASE64 = True
USE_COMPRS = False

if USE_NORMAL:
    #Normal Array => var ccode = [0, 1, 3, 0, ...]
    Path = "C:/TobaWeb/TobaWebApp/"
    input = "index.toc"
    output = Path + "toba_script.js"
    with open(input, 'rb') as f:
        data = f.read()
    out = bin2header(data, 'ccode')
    out = out.replace("{", "[")
    out = out.replace("}", "]")
    with open(output, 'w') as f:
        f.write(out)

if USE_BASE64:
    #Base64 string Array => var ccode = var ccode = 'nbnbnbbn...=='
    Path = "C:/TobaWeb/TobaWebApp/"
    input = "index.toc"
    output = Path + "toba_script.js"
    with open(input, 'rb') as f:
        data = f.read()
    out = "var ccode = " + repr(base64.b64encode(data))
    out = out.replace("b'","'")
    with open(output, 'w') as f:
        f.write(out) 
     
if USE_COMPRS:
    x = lzstring.LZString()
    Path = "C:/TobaWeb/TobaWebApp/"
    input = "index.toc"
    output = Path + "toba_script.js"
    with open(input, 'rb') as f:
        data = f.read()
    # out = "var ccode = " + repr(base64.b64encode(data))
    out = "var ccode = \"" + x.compressToBase64(repr(data)) + "\""
    with open(output, 'w') as f:
        f.write(out)     